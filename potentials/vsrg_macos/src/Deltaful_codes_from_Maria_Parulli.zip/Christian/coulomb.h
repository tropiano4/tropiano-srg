#ifndef COULOMB_H
#define COULOMB_H
void 
coulomb_fg_(double * eta, double * x, double * l, 
	double * fl, double * gl, double * flp, double * glp);
#endif //COULOMB_H

